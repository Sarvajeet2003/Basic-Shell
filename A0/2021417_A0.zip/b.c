#include<stdio.h>
#include<stdlib.h>

int main(){
    int n;
    printf("Enter the Integer: ");
    scanf("%d",&n);
    printf("%d\n",n);
    char A[10];
    printf("Enter the String: ");
    scanf("%s",A);
    printf("%s\n",A);
}